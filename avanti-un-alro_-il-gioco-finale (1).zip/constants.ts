export const TOTAL_QUESTIONS = 21;
export const GAME_DURATION_SECONDS = 150;
