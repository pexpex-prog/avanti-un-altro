import { GoogleGenAI, Type, GenerateContentResponse } from "@google/genai";
import { Question } from '../types';
import { TOTAL_QUESTIONS } from '../constants';

if (!process.env.API_KEY) {
  throw new Error("API_KEY environment variable is not set.");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const questionGenerationSchema = {
  type: Type.ARRAY,
  items: {
    type: Type.OBJECT,
    properties: {
      question: {
        type: Type.STRING,
        description: "Una domanda semplice di cultura generale. (es. 'Di che colore è il cielo?')"
      },
      correctAnswer: {
        type: Type.STRING,
        description: "La risposta corretta alla domanda. (es. 'Azzurro')"
      },
      incorrectAnswer: {
        type: Type.STRING,
        description: "Una risposta plausibile ma sbagliata. (es. 'Verde')"
      }
    },
    required: ["question", "correctAnswer", "incorrectAnswer"],
  }
};


export const generateQuestions = async (): Promise<Question[]> => {
  try {
    const response: GenerateContentResponse = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: `Genera ${TOTAL_QUESTIONS} domande semplici e veloci di cultura generale in italiano, adatte al gioco 'Avanti un Altro'. Per ogni domanda, fornisci la risposta corretta e una risposta sbagliata ma plausibile.`,
      config: {
        responseMimeType: "application/json",
        responseSchema: questionGenerationSchema,
      },
    });

    const jsonText = response.text.trim();
    const questions = JSON.parse(jsonText);
    
    // Validate that we received the correct number of questions
    if (!Array.isArray(questions) || questions.length !== TOTAL_QUESTIONS) {
        console.error("Generated data is not an array of the correct length:", questions);
        throw new Error(`Expected ${TOTAL_QUESTIONS} questions, but received a different structure.`);
    }

    return questions;
  } catch (error) {
    console.error("Error generating questions:", error);
    throw new Error("Impossibile generare le domande. Controlla la tua chiave API e riprova.");
  }
};
